<?php echo e($slot); ?>

<?php /**PATH D:\Magang Tonjoo\AmiCloud_Apps\Backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>